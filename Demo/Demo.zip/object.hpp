#ifndef MY_OBJECT
#define MY_OBJECT
#include <bits/stdc++.h>

struct Object {
  unsigned DisappearFrame;
  unsigned x, y;
};
#endif