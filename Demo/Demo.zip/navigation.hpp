#ifndef MY_NAVI
#define MY_NAVI
#include <bits/stdc++.h>

using namespace std;
#endif
