#ifndef MY_ARRANGE
#define MY_ARRANGE
#include <bits/stdc++.h>
using namespace std;
struct Hub {
  unsigned id, x, y;
} Hubs[1005];

#endif